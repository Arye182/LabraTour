# Project Name : "LabraTour"

# Description  
A - Mobile Android App that helps getting customized reccomended Points-Of-Interests. 

![Alt ScreenShot](/FlightControlWeb/ClientApp/src/images/flight_screen.PNG?raw=true "ScreenShot 1")


UI / UX:
-----------------------------
* Kotlin - Android Studio
* Material Design - Components
* One Activity Architecture
* Module - App
* Navigation Component of Android X jetpack


Back - End:
-----------------------------
* 
* 
* 
* 
* 

FlightControlUnitTests (Unit-Tests):
-----------------------------
* 
* 
	


# System Requiremnets  


# Installation  


# Support  
arye.amsalem@gmail.com  
miriyungreis@gmail.com

# Roadmap  
none.

# Contributing  
none.

# Authors and acknowledgment  
Arye182, miriyungreis

# License  
MIT

# Project status  
on progress

# Git Hub Link ~ ~ for instructors 89111
https://github.com/Arye182/LabraTour
